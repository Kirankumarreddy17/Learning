function showSection(id){
  document.querySelectorAll('.page-section').forEach(sec=>sec.classList.remove('active-section'));
  document.getElementById(id).classList.add('active-section');
}
document.getElementById('year').textContent = new Date().getFullYear();