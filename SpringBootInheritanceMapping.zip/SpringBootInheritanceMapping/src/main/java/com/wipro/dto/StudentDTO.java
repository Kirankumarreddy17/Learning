package com.wipro.dto;

public class StudentDTO {

}
