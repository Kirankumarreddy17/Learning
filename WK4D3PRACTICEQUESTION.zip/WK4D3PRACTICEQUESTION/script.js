document.getElementById('fetchBtn').addEventListener('click', () => {
  fetch("https://randomuser.me/api/")
    .then(response => response.json())
    .then(data => {
      const user = data.results[0];
      document.getElementById('userImage').src = user.picture.large;
      document.getElementById('userName').textContent = `${user.name.first} ${user.name.last}`;
      document.getElementById('userEmail').textContent = user.email;

      document.getElementById('userCard').style.display = "block";
    })
    .catch(err => console.error("Error fetching user:", err));
});
