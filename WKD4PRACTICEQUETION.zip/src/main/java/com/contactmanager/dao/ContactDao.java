package com.contactmanager.dao;
import com.contactmanager.model.Contact;
import java.util.*;
public class ContactDao {
    private static List<Contact> contacts = new ArrayList<>();
    private static int idCounter = 1;
    public List<Contact> getAllContacts() { return contacts; }
    public void addContact(Contact c) { c.setId(idCounter++); contacts.add(c); }
    public Contact getContactById(int id) {
        for(Contact c : contacts) if(c.getId() == id) return c; return null;
    }
    public boolean updateContact(Contact updatedContact) {
        Contact c = getContactById(updatedContact.getId());
        if(c != null) {
            c.setName(updatedContact.getName());
            c.setEmail(updatedContact.getEmail());
            c.setPhone(updatedContact.getPhone());
            return true;
        }
        return false;
    }
    public boolean deleteContact(int id) {
        Contact c = getContactById(id);
        if(c != null) { contacts.remove(c); return true; }
        return false;
    }
}