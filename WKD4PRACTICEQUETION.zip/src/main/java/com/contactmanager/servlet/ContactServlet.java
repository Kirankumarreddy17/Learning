package com.contactmanager.servlet;
import com.contactmanager.dao.ContactDao;
import com.contactmanager.model.Contact;
import javax.servlet.*; import javax.servlet.http.*;
import java.io.IOException;
public class ContactServlet extends HttpServlet {
    private ContactDao dao = new ContactDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action"); if(action==null) action="list";
        switch(action) {
            case "add": request.getRequestDispatcher("/jsp/addContact.jsp").forward(request,response); break;
            case "edit":
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("contact", dao.getContactById(id));
                request.getRequestDispatcher("/jsp/editContact.jsp").forward(request,response); break;
            case "delete":
                id = Integer.parseInt(request.getParameter("id"));
                boolean deleted = dao.deleteContact(id);
                request.setAttribute("message", deleted ? "Contact deleted successfully!" : "Contact not found!");
                request.getRequestDispatcher("/jsp/message.jsp").forward(request,response); break;
            default:
                request.setAttribute("contacts", dao.getAllContacts());
                request.getRequestDispatcher("/jsp/listContacts.jsp").forward(request,response);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if("add".equals(action)) {
            Contact c = new Contact();
            c.setName(request.getParameter("name"));
            c.setEmail(request.getParameter("email"));
            c.setPhone(request.getParameter("phone"));
            dao.addContact(c);
            request.setAttribute("message", "Contact added successfully!");
        } else if("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Contact updated = new Contact(id, request.getParameter("name"), request.getParameter("email"), request.getParameter("phone"));
            boolean updatedStatus = dao.updateContact(updated);
            request.setAttribute("message", updatedStatus ? "Contact updated successfully!" : "Contact not found!");
        }
        request.getRequestDispatcher("/jsp/message.jsp").forward(request,response);
    }
}